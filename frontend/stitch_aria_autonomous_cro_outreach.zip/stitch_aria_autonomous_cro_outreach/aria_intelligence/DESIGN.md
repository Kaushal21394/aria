---
name: Aria Intelligence
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#c4c6cc'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#8e9196'
  outline-variant: '#44474c'
  surface-tint: '#bac8dc'
  primary: '#bac8dc'
  on-primary: '#243141'
  primary-container: '#0d1b2a'
  on-primary-container: '#768497'
  inverse-primary: '#525f71'
  secondary: '#4fdbc8'
  on-secondary: '#003731'
  secondary-container: '#04b4a2'
  on-secondary-container: '#003f38'
  tertiary: '#d0bcff'
  on-tertiary: '#3c0091'
  tertiary-container: '#210058'
  on-tertiary-container: '#9364fe'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#d6e4f9'
  primary-fixed-dim: '#bac8dc'
  on-primary-fixed: '#0f1c2c'
  on-primary-fixed-variant: '#3a4859'
  secondary-fixed: '#71f8e4'
  secondary-fixed-dim: '#4fdbc8'
  on-secondary-fixed: '#00201c'
  on-secondary-fixed-variant: '#005048'
  tertiary-fixed: '#e9ddff'
  tertiary-fixed-dim: '#d0bcff'
  on-tertiary-fixed: '#23005c'
  on-tertiary-fixed-variant: '#5516be'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  display-xl:
    fontFamily: Manrope
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Manrope
    fontSize: 30px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-md:
    fontFamily: Manrope
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: '1.5'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.4'
  data-mono:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1'
    letterSpacing: 0.05em
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1'
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 40px
  gutter: 20px
  container-max: 1440px
---

## Brand & Style

The design system is engineered to project **mathematical precision** and **strategic authority**. As an AI agent focused on Conversion Rate Optimization (CRO), the interface must bridge the gap between complex data processing and actionable business intelligence. 

The style is **Corporate Modern with a "Glass-Data" inflection**. It utilizes a structured, high-density layout to accommodate multifaceted metrics while employing subtle translucent layers to signal the "depth" of AI reasoning. The aesthetic avoids decorative fluff in favor of functional elegance, ensuring that users—primarily growth leads and data analysts—feel they are interacting with a high-performance instrument rather than a simple dashboard. The emotional goal is "Informed Confidence."

## Colors

The palette is anchored in a **Deep Oceanic Dark Mode** to reduce visual fatigue during prolonged data analysis. 

*   **Primary (Foundation):** Deep Navy (#0D1B2A) and Midnight (#020617) provide a stable, "enterprise" foundation that signifies security and depth.
*   **Secondary (Trust & Growth):** Teals (#14B8A6) are used for "Success" states and positive conversion trends, reinforcing the CRO focus.
*   **Tertiary (AI Intelligence):** Electric Violet (#8B5CF6) is reserved exclusively for AI-generated insights, agentic suggestions, and automated actions.
*   **Accent (Precision):** High-brightness Cyan (#22D3EE) is used for active data points, hover states, and critical paths.
*   **System Status:** Use standard semantic reds and oranges for friction points or negative trends, but desaturate them slightly to fit the cool-toned environment.

## Typography

This design system utilizes a three-tier typographic approach to balance readability with a technical edge:

1.  **Manrope (Headlines):** Used for structural hierarchy. Its balanced, modern proportions feel premium and organized.
2.  **Inter (Body & UI):** The workhorse for data density. It ensures maximum legibility in complex tables and dense property panels.
3.  **Space Grotesk (Data & Labels):** Employed for numerical values, metric labels, and technical metadata. Its geometric, slightly futuristic character emphasizes the "AI" and "Tech" nature of the agent.

All numerical data should use tabular figures to ensure alignment in comparison lists.

## Layout & Spacing

The layout follows a **structured 12-column fluid grid** for primary dashboard views, transitioning to a flexible "agentic" layout for the interaction sidebars.

*   **Rhythm:** A 4px baseline grid governs all spatial relationships.
*   **Density:** The design system prioritizes information density. Use 16px (md) padding for standard cards and 8px (sm) for nested data clusters.
*   **Sidebars:** A dual-sidebar model is recommended. Left for global navigation; Right for the AI Agent "Thought Stream" and context-specific controls.
*   **Margins:** Use wide 40px (xl) exterior margins on desktop to prevent the interface from feeling "cramped" despite high internal density.

## Elevation & Depth

Depth is communicated through **Tonal Layering and Glassmorphism** rather than traditional heavy shadows.

*   **Level 0 (Background):** The deepest layer, solid #020617.
*   **Level 1 (Sub-base):** Surfaces used for the main workspace, #0F172A.
*   **Level 2 (Cards/Modules):** Elements that sit on the sub-base. These use a subtle 1px inner border (Stroke: #FFFFFF, 8% opacity) to create definition.
*   **Level 3 (Popovers/Modals):** These use a **Backdrop Blur (20px)** and a semi-transparent fill to imply they are floating "above" the data stream.
*   **AI Highlights:** Elements generated or highlighted by the AI should use a subtle outer glow (60px blur, 10% opacity) in the Electric Violet or Cyan color to draw the eye without breaking the grid.

## Shapes

The shape language is **Technical and Precise**. 

*   **Standard Components:** Buttons and input fields use a 4px (Soft) radius to maintain a professional, "to-the-edge" appearance. 
*   **Cards:** Use an 8px (lg) radius to create clear containment for data modules.
*   **Agent Elements:** The AI chat bubbles or "insight cards" use a slightly more pronounced 12px (xl) corner on one side to distinguish them as "active intelligence" versus "static data."
*   **Icons:** Use 2px stroke weights with squared-off terminals to match the font geometry.

## Components

### Buttons & Inputs
*   **Primary Action:** Solid Teal gradient (Bottom-Right to Top-Left) with white text. High contrast for conversion-driving actions.
*   **AI Action:** Ghost button with an Electric Violet border and a 5% violet fill on hover.
*   **Inputs:** Dark backgrounds (#020617) with 1px borders. Focus states should use a glowing 1px Cyan ring.

### Cards
*   **Metric Cards:** Feature a "Space Grotesk" large-format number. Use a micro-sparkline in the background of the card to show 24h trends.
*   **Insight Cards:** Distinctive cards with a left-edge border accent in Electric Violet. These house the AI’s "Takeaways."

### Data Tables
*   **Compact Styling:** Minimal vertical padding. Use "Zebra striping" with very low opacity shifts (2%) rather than borders to separate rows.
*   **Status Indicators:** Use small, high-saturation "pills" for status, ensuring the text remains legible at 11px.

### Agentic Specifics
*   **The "Thought Stream":** A vertical feed of AI activities. Each node in the stream is connected by a thin, dashed cyan line to show the progression of logic.
*   **Confidence Scores:** Circular progress rings (Cyan) that appear next to AI suggestions to quantify the agent's certainty.